import{e as s,j as a}from"./react-core-Bfiii5cx.js";import{bl as l,aX as o}from"./index-CpYr3adb.js";import{L as i}from"./router-BVzygNlZ.js";import"./supabase-3YfAq9Bl.js";import"./icons-D1Z8s3g4.js";const r=[{slug:"apa-itu-hris",title:"Apa itu HRIS? Panduan Lengkap untuk Perusahaan Indonesia 2026",excerpt:"HRIS (Human Resource Information System) adalah sistem digital yang mengintegrasikan seluruh proses HR. Pelajari manfaat, fitur, dan cara memilih HRIS yang tepat.",category:"Panduan",readTime:"8 menit",date:"2026-05-20",keywords:["apa itu HRIS","HRIS adalah","sistem HR digital"],content:`
      <h2>Apa itu HRIS?</h2>
      <p>HRIS (Human Resource Information System) atau Sistem Informasi Sumber Daya Manusia adalah platform perangkat lunak yang mengintegrasikan seluruh proses manajemen HR dalam satu sistem terpusat. Dengan HRIS, perusahaan dapat mengelola data karyawan, absensi, penggajian, rekrutmen, dan penilaian kinerja secara digital dan efisien.</p>

      <h2>Mengapa Perusahaan Indonesia Butuh HRIS?</h2>
      <p>Di era digital ini, pengelolaan HR secara manual dengan spreadsheet Excel sangat tidak efisien dan rentan kesalahan. HRIS modern seperti KiniKerja hadir untuk membantu perusahaan Indonesia naik kelas dengan:</p>
      <ul>
        <li><strong>Hemat waktu:</strong> Proses penggajian yang butuh berhari-hari jadi hanya 1 klik</li>
        <li><strong>Minim error:</strong> Perhitungan otomatis BPJS, PPh 21, lembur</li>
        <li><strong>Real-time:</strong> Absensi GPS langsung terdata tanpa perlu rekap manual</li>
        <li><strong>Compliance:</strong> Otomatis sesuai regulasi ketenagakerjaan Indonesia</li>
      </ul>

      <h2>Fitur Utama HRIS Modern</h2>
      <p>Platform HRIS terbaik untuk perusahaan Indonesia wajib memiliki:</p>
      <ul>
        <li>Manajemen data karyawan terpusat</li>
        <li>Absensi GPS real-time dengan geofencing</li>
        <li>Penggajian otomatis dengan kalkulasi BPJS & PPh 21</li>
        <li>Manajemen cuti & izin digital</li>
        <li>Rekrutmen & onboarding end-to-end</li>
        <li>Penilaian kinerja KPI & 360 derajat</li>
        <li>Laporan HR real-time</li>
      </ul>

      <h2>Berapa Biaya HRIS untuk Perusahaan Indonesia?</h2>
      {/* KEEP IN SYNC with src/lib/plans.js CANONICAL_PLANS (Starter 149000 / Pro 299000) */}
      <p>KiniKerja menawarkan harga yang sangat terjangkau mulai dari <strong>Rp 149.000/bulan</strong> untuk paket Starter (hingga 25 karyawan) dan <strong>Rp 299.000/bulan</strong> untuk paket Pro (hingga 100 karyawan). Berlangganan tahunan mendapat diskon.</p>
    `},{slug:"absensi-karyawan-digital",title:"Sistem Absensi Karyawan Digital: Manfaat & Cara Implementasi 2026",excerpt:"Absensi karyawan digital dengan GPS geofencing membantu perusahaan menghilangkan fraud absensi dan meningkatkan akurasi payroll hingga 100%.",category:"Tips HR",readTime:"6 menit",date:"2026-05-22",keywords:["absensi karyawan digital","sistem absensi online","absensi GPS"],content:`
      <h2>Masalah Absensi Manual yang Sering Terjadi</h2>
      <p>Sistem absensi manual menghadapi berbagai masalah: titip absen, rekap yang lambat, data tidak akurat, hingga kesulitan memantau karyawan WFH atau lapangan. Inilah mengapa sistem absensi digital menjadi kebutuhan wajib perusahaan modern Indonesia.</p>

      <h2>Keunggulan Absensi GPS dengan Geofencing</h2>
      <p>Absensi GPS real-time seperti yang ada di KiniKerja memiliki keunggulan:</p>
      <ul>
        <li>Verifikasi lokasi otomatis - karyawan hanya bisa absen di dalam radius yang ditentukan</li>
        <li>Anti fraud - tidak bisa titip absen karena pakai GPS + selfie</li>
        <li>Real-time dashboard - HRD langsung lihat siapa yang belum absen</li>
        <li>Otomatis terhubung ke payroll - potongan terlambat/alpha dihitung otomatis</li>
      </ul>

      <h2>Cara Implementasi Absensi Digital di Perusahaan</h2>
      <p>Implementasi KiniKerja untuk absensi digital hanya butuh 3 langkah: (1) Daftar dan setup profil perusahaan, (2) Import data karyawan, (3) Karyawan install PWA di smartphone. Selesai dalam 5 menit!</p>
    `},{slug:"penggajian-otomatis-bpjs",title:"Cara Hitung Gaji Karyawan Otomatis dengan Potongan BPJS & PPh 21",excerpt:"Panduan lengkap menghitung gaji karyawan di Indonesia termasuk BPJS Ketenagakerjaan, BPJS Kesehatan, PPh 21, dan lembur - semuanya bisa otomatis dengan HRIS.",category:"Payroll",readTime:"10 menit",date:"2026-05-24",keywords:["penggajian otomatis","hitung gaji BPJS PPh21","payroll Indonesia"],content:`
      <h2>Komponen Gaji Karyawan di Indonesia</h2>
      <p>Penggajian karyawan di Indonesia melibatkan banyak komponen yang harus dihitung dengan akurat:</p>
      <ul>
        <li>Gaji pokok</li>
        <li>Tunjangan tetap (transport, makan, jabatan)</li>
        <li>Uang lembur sesuai aturan Kemnaker</li>
        <li>BPJS Ketenagakerjaan (JHT 2%, JP 1%, JKK 0.24%, JKM 0.3%)</li>
        <li>BPJS Kesehatan (1% ditanggung karyawan)</li>
        <li>PPh 21 (progressive sesuai PTKP)</li>
      </ul>

      <h2>Mengapa Penggajian Manual Berisiko?</h2>
      <p>Kesalahan hitung penggajian bisa berakibat fatal: sanksi dari BPJS, protes karyawan, hingga masalah hukum. Dengan KiniKerja, semua perhitungan dilakukan otomatis dan akurat sesuai regulasi terbaru.</p>

      <h2>Fitur Payroll KiniKerja</h2>
      <p>Modul payroll KiniKerja mengkalkulasi seluruh komponen gaji secara otomatis, menghasilkan slip gaji digital, dan bisa langsung transfer ke rekening karyawan. Hemat waktu tim HR hingga 80%.</p>
    `},{slug:"software-hr-terbaik-indonesia",title:"5 Software HR Terbaik untuk Perusahaan Indonesia 2026",excerpt:"Perbandingan software HR Indonesia terbaik: fitur, harga, dan keunggulan. Temukan mana yang paling sesuai untuk kebutuhan perusahaan Anda.",category:"Review",readTime:"12 menit",date:"2026-05-26",keywords:["software HR terbaik Indonesia","aplikasi HR perusahaan","HRIS terbaik"],content:`
      <h2>Kriteria Memilih Software HR Terbaik</h2>
      <p>Dalam memilih software HR untuk perusahaan Indonesia, perhatikan: (1) Lengkap fiturnya, (2) Harga terjangkau, (3) Mudah digunakan, (4) Support bahasa Indonesia, (5) Comply dengan regulasi Indonesia.</p>

      <h2>Kenapa KiniKerja Unggul?</h2>
      <p>KiniKerja dirancang khusus untuk perusahaan Indonesia dengan mempertimbangkan regulasi lokal, bahasa Indonesia, dan kebutuhan spesifik HR di Indonesia seperti BPJS, PPh 21, dan aturan Kemnaker.</p>
      <ul>
        {/* KEEP IN SYNC with src/lib/plans.js CANONICAL_PLANS prices */}
        <li>œ... Harga mulai Rp 149.000/bulan - paling terjangkau</li>
        <li>œ... Bahasa Indonesia penuh</li>
        <li>œ... Absensi GPS geofencing anti fraud</li>
        <li>œ... Payroll otomatis BPJS & PPh 21</li>
        <li>œ... PWA - bisa diinstall di HP tanpa app store</li>
        <li>œ... Support WhatsApp langsung</li>
      </ul>
    `}],g={"@context":"https://schema.org","@type":"Blog",name:"Blog KiniKerja - Tips & Panduan HR Indonesia",description:"Artikel, panduan, dan tips seputar manajemen SDM, absensi digital, payroll, dan software HR untuk perusahaan Indonesia.",url:"https://kinikerja.com/blog",publisher:{"@type":"Organization",name:"KiniKerja",logo:{"@type":"ImageObject",url:"https://kinikerja.com/landing/kinikerjabluepanjang.png"}},blogPost:r.map(e=>({"@type":"BlogPosting",headline:e.title,description:e.excerpt,url:`https://kinikerja.com/blog/${e.slug}`,datePublished:e.date,author:{"@type":"Organization",name:"KiniKerja"},keywords:e.keywords.join(", ")}))},n={nav:{padding:"16px 24px",display:"flex",alignItems:"center",justifyContent:"space-between",borderBottom:"1px solid #E2E8F0",background:"#fff",position:"sticky",top:0,zIndex:100,flexWrap:"wrap",gap:8},logo:{fontSize:20,fontWeight:600,color:"#635BFF",textDecoration:"none"},hero:{background:"linear-gradient(135deg, #F0EEFF 0%, #fff 60%)",padding:"60px 20px 48px",textAlign:"center"},h1:{fontSize:"clamp(26px, 4vw, 40px)",fontWeight:600,color:"#0F172A",marginBottom:12,lineHeight:1.2},sub:{fontSize:17,color:"#475569",maxWidth:580,margin:"0 auto",lineHeight:1.6},grid:{display:"grid",gridTemplateColumns:"repeat(auto-fill, minmax(280px, 1fr))",gap:24,maxWidth:1100,margin:"0 auto",padding:"48px 20px 80px"},card:{background:"#fff",border:"1.5px solid #E2E8F0",borderRadius:16,overflow:"hidden",transition:"all 0.2s",display:"flex",flexDirection:"column",cursor:"pointer"},cardImg:{height:8,background:"linear-gradient(135deg, #635BFF, #635BFF)"},cardBody:{padding:24,flex:1,display:"flex",flexDirection:"column"},category:{fontSize:11,fontWeight:600,color:"#635BFF",textTransform:"uppercase",letterSpacing:1,marginBottom:8},cardTitle:{fontSize:17,fontWeight:600,color:"#0F172A",marginBottom:10,lineHeight:1.4},cardExcerpt:{fontSize:14,color:"#64748B",lineHeight:1.6,flex:1},meta:{display:"flex",alignItems:"center",gap:12,marginTop:16,fontSize:12,color:"#94A3B8"},readMore:{display:"inline-block",marginTop:16,color:"#635BFF",fontWeight:700,fontSize:14,textDecoration:"none"},cta:{background:"linear-gradient(135deg, #635BFF, #5449FF)",padding:"56px 24px",textAlign:"center"}};function k(){return s.useEffect(()=>{l({title:"Blog HR Indonesia - Tips Manajemen SDM, Payroll & Absensi | KiniKerja",description:"Artikel & panduan HR terlengkap untuk perusahaan Indonesia: cara hitung gaji BPJS PPh21, sistem absensi digital, software HR terbaik, implementasi HRIS. Gratis dibaca!",canonical:"https://kinikerja.com/blog",keywords:"blog HR Indonesia, panduan HRIS, tips manajemen SDM, cara hitung gaji BPJS, software HR Indonesia"}),o("blog-page",g)},[]),a.jsxs(a.Fragment,{children:[a.jsxs("nav",{style:n.nav,children:[a.jsx(i,{to:"/",style:n.logo,children:"KiniKerja"}),a.jsxs("div",{style:{display:"flex",gap:16,alignItems:"center"},children:[a.jsx(i,{to:"/harga",style:{fontSize:14,color:"#64748B",textDecoration:"none",fontWeight:600},children:"Harga"}),a.jsx(i,{to:"/blog",style:{fontSize:14,color:"#635BFF",textDecoration:"none",fontWeight:700,borderBottom:"2px solid #635BFF",paddingBottom:2},children:"Blog"}),a.jsx(i,{to:"/checkout",style:{padding:"8px 20px",background:"#635BFF",color:"#fff",borderRadius:10,fontSize:14,fontWeight:700,textDecoration:"none"},children:"Mulai Sekarang"})]})]}),a.jsxs("header",{style:n.hero,children:[a.jsx("div",{style:{fontSize:12,fontWeight:600,color:"#635BFF",textTransform:"uppercase",letterSpacing:2,marginBottom:12},children:"Blog & Sumber Daya HR"}),a.jsx("h1",{style:n.h1,children:"Tips & Panduan HR untuk Perusahaan Indonesia"}),a.jsx("p",{style:n.sub,children:"Artikel praktis seputar manajemen SDM, penggajian, absensi digital, dan software HR - ditulis khusus untuk konteks bisnis Indonesia."})]}),a.jsxs("main",{children:[a.jsx("div",{style:n.grid,children:r.map((e,t)=>a.jsxs("article",{style:n.card,children:[a.jsx("div",{style:{...n.cardImg,background:t%2===0?"linear-gradient(135deg, #635BFF, #635BFF)":"linear-gradient(135deg, #7C3AED, #A855F7)"}}),a.jsxs("div",{style:n.cardBody,children:[a.jsxs("div",{style:n.category,children:[e.category,"  ",e.readTime," baca"]}),a.jsx("h2",{style:n.cardTitle,children:e.title}),a.jsx("p",{style:n.cardExcerpt,children:e.excerpt}),a.jsx("div",{style:n.meta,children:a.jsxs("span",{children:['Ÿ"... ',new Date(e.date).toLocaleDateString("id-ID",{day:"numeric",month:"long",year:"numeric"})]})}),a.jsx(i,{to:`/blog/${e.slug}`,style:n.readMore,children:"Baca selengkapnya →"})]})]},t))}),a.jsxs("div",{style:n.cta,children:[a.jsx("h2",{style:{fontSize:20,fontWeight:600,color:"#fff",marginBottom:12},children:"Siap Digitalisasi HR Perusahaan Anda?"}),a.jsx("p",{style:{color:"rgba(255,255,255,0.85)",marginBottom:28,fontSize:16},children:"Mulai dengan paket Starter hanya Rp 149.000/bulan. Tanpa kontrak, batalkan kapan saja."}),a.jsx(i,{to:"/checkout",style:{display:"inline-block",padding:"14px 36px",background:"#fff",color:"#635BFF",borderRadius:12,fontWeight:600,fontSize:16,textDecoration:"none"},children:"Coba KiniKerja Sekarang →"})]})]})]})}export{r as ARTICLES,k as default};
