import{ae as o}from"./index-CpYr3adb.js";const e=[["path",{d:"m7 15 5 5 5-5",key:"1hf1tw"}],["path",{d:"m7 9 5-5 5 5",key:"sgt6xg"}]],n=o("chevrons-up-down",e);export{n as C};
