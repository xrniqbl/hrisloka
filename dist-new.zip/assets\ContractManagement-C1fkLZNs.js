import{E as R}from"./jspdf.es.min-C2nDCNHh.js";import D from"./html2canvas.esm-DXEQVQnt.js";import S from"./purify-BPuvlvQ_.js";const v=`
  * { box-sizing: border-box; }
  body, html { margin: 0; padding: 0; }
  .contract-doc, .contract-body {
    font-family: 'Times New Roman', Times, serif !important;
    font-size: 12pt;
    line-height: 1.7;
    color: #000;
  }
  table { width: 100%; border-collapse: collapse; }
  td, th { border: 1px solid #333; padding: 6px 10px; font-size: 11pt; }
  h1, h2, h3 { font-family: 'Times New Roman', Times, serif; }
  .signature-block { margin-top: 40px; }
  p { margin: 0 0 8px; }
`;async function F(b,f="contract"){const o=document.createElement("div");o.id="__pdf_render__",Object.assign(o.style,{position:"fixed",top:"-99999px",left:"-99999px",width:"794px",background:"#ffffff",padding:"40px 60px",margin:"0",zIndex:"-9999",fontFamily:"'Times New Roman', serif",fontSize:"12pt",lineHeight:"1.7",color:"#000"});const u=S.sanitize(b,{FORBID_TAGS:["script","iframe","object","embed","form","input"]});o.innerHTML=`<style>${v}</style>${u}`,document.body.appendChild(o);try{const d=await D(o,{scale:2,useCORS:!0,logging:!1,backgroundColor:"#ffffff",width:794}),s=210,p=297,t=15,y=10,g=s-t*2,l=p-t-y-t,c=d.width,h=d.height,r=c/g,w=h/r,x=Math.ceil(w/l),e=new R({orientation:"portrait",unit:"mm",format:"a4"});for(let n=0;n<x;n++){n>0&&e.addPage();const _=Math.round(n*l*r),a=Math.round(Math.min(l*r,h-_));if(a<=0)break;const m=document.createElement("canvas");m.width=c,m.height=a,m.getContext("2d").drawImage(d,0,_,c,a,0,0,c,a);const C=m.toDataURL("image/png"),H=a/r;e.addImage(C,"PNG",t,t,g,H);const i=p-t/2-2;e.setDrawColor(210,210,210),e.line(t,i-5,s-t,i-5),e.setFontSize(8),e.setTextColor(160,160,160),e.text(`Halaman ${n+1} dari ${x}`,t,i,{align:"left"}),e.text(f,s/2,i,{align:"center"}),e.text("Dibuat oleh KiniKerja",s-t,i,{align:"right"})}const P=new Date().toISOString().split("T")[0],T=f.replace(/[/\\:*?"<>|]/g,"-");e.save(`Kontrak_${T}_${P}.pdf`)}finally{o.parentNode&&document.body.removeChild(o)}}export{F as g};
