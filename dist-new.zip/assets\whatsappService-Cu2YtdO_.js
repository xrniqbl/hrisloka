import{bd as s}from"./index-CpYr3adb.js";import"./react-core-Bfiii5cx.js";import"./supabase-3YfAq9Bl.js";import"./icons-D1Z8s3g4.js";import"./router-BVzygNlZ.js";async function o(){const{data:{session:e}}=await s.auth.getSession(),a={"Content-Type":"application/json"};return e?.access_token&&(a.Authorization=`Bearer ${e.access_token}`),a}async function u(e,a){if(!e)return{success:!1,error:"No phone number"};try{const i=await fetch("/api/send-whatsapp",{method:"POST",headers:await o(),body:JSON.stringify({to:e,message:a})}),t=await i.json().catch(()=>({}));if(!i.ok||!t.success)throw new Error(t.error||"Server WA error");return{success:!0}}catch(i){return console.error("[WhatsApp] Send failed:",i),{success:!1,error:i.message}}}function K(e,a,i,t,n){return`🏢 *KiniKerja — Notifikasi Cuti*

Halo, *${e}*!

Pengajuan cuti kamu telah *${a==="approved"?"DISETUJUI":"DITOLAK"}* ${a==="approved"?"✅":"❌"}

📋 *Detail Cuti:*
• Jenis: ${i}
• Mulai: ${t}
• Selesai: ${n}

${a==="approved"?"Selamat menikmati cuti kamu! 🌟":"Silakan hubungi HRD untuk informasi lebih lanjut."}

_KiniKerja — Smart HR Platform_`}function h(e,a,i,t){return`🏢 *KiniKerja — Slip Gaji Tersedia*

Halo, *${e}*!

Slip gaji kamu untuk periode *${a} ${i}* sudah tersedia di aplikasi.

💰 *Total Diterima:*
*Rp ${Number(t).toLocaleString("id-ID")}*

Buka aplikasi KiniKerja untuk melihat rincian lengkap dan download slip gaji.

_KiniKerja — Smart HR Platform_`}function j(e){const a=new Date().toLocaleTimeString("id-ID",{hour:"2-digit",minute:"2-digit"});return`🕐 *KiniKerja — Pengingat Absensi*

Halo, *${e}*!

Jangan lupa absen masuk hari ini ya! 👋

Sekarang pukul *${a} WIB*.
Segera buka aplikasi KiniKerja untuk clock-in.

_KiniKerja — Smart HR Platform_`}function k(e,a,i){return`📋 *KiniKerja — Perlu Persetujuan*

Halo, *${e}*!

Ada *${a} pengajuan ${i}* yang menunggu persetujuan kamu.

Buka portal KiniKerja untuk memproses pengajuan tersebut.

_KiniKerja — Smart HR Platform_`}function f(e,a,i,t){return`🏢 *KiniKerja — Notifikasi Reimburse*

Halo, *${e}*!

Pengajuan reimbursement kamu telah *${a==="approved"?"DISETUJUI":a==="paid"?"DIBAYARKAN":"DITOLAK"}* ${a==="approved"?"✅":a==="paid"?"💰":"❌"}

📋 *Detail:*
• Kategori: ${t}
• Jumlah: Rp ${Number(i).toLocaleString("id-ID")}

_KiniKerja — Smart HR Platform_`}async function S(){try{return(await fetch("/api/send-whatsapp",{method:"OPTIONS"})).status<500}catch{return!1}}async function b(e){return u(e,`✅ *Test Berhasil!*

Koneksi WhatsApp KiniKerja berhasil dikonfigurasi.

_Pesan ini dikirim dari KiniKerja Integration Hub._`)}export{k as buildApprovalReminderMessage,j as buildClockInReminderMessage,K as buildLeaveStatusMessage,h as buildPayslipMessage,f as buildReimbursementMessage,S as isWhatsAppConfigured,u as sendWhatsApp,b as testWhatsAppConnection};
